export default function Input(theme: any) {
  const disabledStyle = {};

  return {};
}
