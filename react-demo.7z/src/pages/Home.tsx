const HomePage = () => {
  return <div>Home page</div>;
};

export default HomePage;
