const Dashboard = () => {
  return <div>Dashbaord</div>;
};

export default Dashboard;
