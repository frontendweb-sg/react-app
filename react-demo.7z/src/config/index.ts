export const config = {
  drawerFullWidth: 280,
  drawerSmallWidth: 80,
};
