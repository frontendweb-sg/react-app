export const AppRoute = {
  root: "/",
  login: "/auth",
  register: "/auth/register",
  admin: "/admin",
  adminDashboard: "/admin/dashboard",
};
