import { memo } from "react";
import { AdminSidebarProps, Drawer } from "./style";
import Logo from "../layout/Logo";
import { Box } from "@mui/material";
import { AdminMenu, IMenu } from "@/utils/menus";
import CustomMenuList from "../common/MenuList";

/**
 * Admin sidebar component
 */
const AdminSidebar = memo(function AdminSidebar({
  drawerWidth = 250,
  open,
  variant = "permanent",
  ...rest
}: AdminSidebarProps) {
  return (
    <Drawer variant={variant} anchor="left" open={open} {...rest}>
      <Logo sx={{ display: "block", p: 2 }} to="/admin" />

      <Box>
        <CustomMenuList menus={AdminMenu} />
      </Box>
    </Drawer>
  );
});

export default AdminSidebar;
