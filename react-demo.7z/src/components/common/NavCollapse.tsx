import { useState } from "react";
import { IMenu } from "@/utils/menus";
import { ListItemButton, ListItemIcon } from "@mui/material";
import { memo } from "react";
import { useNavigate } from "react-router-dom";
import useToggle from "@/hooks/useToggle";

type NavCollapseProps = {
  menu: IMenu;
  level?: number;
};
const NavCollapse = memo(function NavCollapse({
  menu,
  level,
}: NavCollapseProps) {
  const { open, handleToggle } = useToggle();
  const [selected, setSelected] = useState(null);

  const navigate = useNavigate();
  return (
    <>
      <ListItemButton
        sx={{
          mb: 0.5,
          alignItems: "flex-start",
          backgroundColor: level! > 1 ? "transparent !important" : "inherit",
          py: level! > 1 ? 1 : 1.25,
          pl: `${level! * 24}px`,
        }}
        selected={selected === menu!.id}
      >
        <ListItemIcon sx={{ my: "auto" }}>{menu.icon}</ListItemIcon>
      </ListItemButton>
    </>
  );
});

export default NavCollapse;
