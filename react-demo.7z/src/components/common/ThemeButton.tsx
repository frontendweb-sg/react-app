import { memo } from "react";

const ThemeButton = memo(function ThemeButton() {
  return <div></div>;
});

export default ThemeButton;
