const AuthHeader = () => {
  return <header></header>;
};
export default AuthHeader;
