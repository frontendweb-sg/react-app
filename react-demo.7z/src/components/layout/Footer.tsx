import Container from "@mui/material/Container";

/**
 * Footer component
 * @returns
 */
const Footer = () => {
  return (
    <footer>
      <Container></Container>
    </footer>
  );
};

export default Footer;
